/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;
import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author Guest
 */
public class FinalProject {
static Scanner scan = new Scanner(System.in);
static Random rand = new Random();
    /**
     * @param args the command line arguments           Nick Johnson Mod 5
     *      
     * 
     * 
     *                      
     * Final Project!
     * 
     * 
     * 
     * Goals Error checking!!!!!! (Top Priority)
     * 
     * 
     * 
     * 
     */ 
    public static void main(String[] args) 
    {
        
        
        //int star;
        FinalProject start = new FinalProject();
        //String answer;
        char answer;
        boolean answer2 = true;
        
        System.out.println("******************************");
        System.out.println("**      WELCOME TO THE      **");
        System.out.println("**      WISCONSON TRAIL     **");
        System.out.println("******************************");
        System.out.println("*** Please type the right letter because it will end the game"
                + "\n    if you choose the wrong letter! ***");
        System.out.println("\n");
        System.out.println("Are you ready to start your adventure? Y or N?");
        answer = scan.nextLine().charAt(0); //start
        while (answer2 == true)
                {
        if (answer == 'y' || answer == 'Y')
        {
            
            System.out.println("Let's Begin!"); //begin game
            start.Gameplay();
            answer2 = false;
        }
       else if (answer == 'n' || answer == 'N'){
            System.out.println("Ok I'll wait till you're ready!\n");
            System.out.println("Enter Y when you are ready"); //wait to begin
            answer = scan.nextLine().charAt(0);
       }
                }
    }
    
    public static void Gameplay() 
    {
        FinalProject game = new FinalProject();
        boolean check = true; //start random events
        int a = 0;
        System.out.println("\nYour on a trek to find the lost cheese of Sir Rodgers");
        System.out.println("You come up to a fork in the road do you go Left(l) or Right(r)?");
        char ans = scan.nextLine().charAt(0);
   //add error check
        if (ans == 'r' || ans == 'R')
        {
            System.out.println("You chose to go right.  " + randomGame() );
            check = false;
        }
        else if (ans == 'l' || ans == 'L')
        {
            System.out.println("You chose to go left. " + randomGame() );
            check = false;
        }
        if  (check == false)
        {
            
            
            Random rand2 = new Random(); //answers to choosing random events
            System.out.println("What will you do?");
            boolean check2 = true;
            char answ = scan.nextLine().charAt(0);
            String hit ;
           while ( check2 == true){
       int chance = rand2.nextInt(100) + 1;
       if (answ == 'c')
       {
           System.out.println("You chose to cry! While you cried a poison snake bit you!\n"
                   + "You DIED!!!! Score 0...Cry about that one why don't you");
           a++;
           check2 = false;
       }
       else if(answ == 'b')
       {
           System.out.println("You chose to continue on your journey!");
           a++;check2 = false;
       }
       if (answ == 'd')
       {
           System.out.println("You chose to drink the poison! You gained 2 times your health!\n"
                   + "Guess it wasn't poison after all!");
           System.out.println(PlayerHealthP()); a++;check2 = false;
       }
       else if(answ == 's')
       {
           System.out.println("You chose save it! Use it wisely!"); a++;check2 = false;
       }
       if (answ == 'h')
       {
           System.out.println("You tried picking up the sword but it's too heavy!\n"
                   + " You got trolled! Will you continue?"); a++;check2 = false;
       }
       if (answ == 't')
       {
           System.out.println("The bunny bit you!"); a++;check2 = false;
       }
       else if(answ == 'w')
       {
           System.out.println("You chose to walk away!"); a++;check2 = false;
       }
        if (answ == 'f')
        {
   System.out.println(BossFight() );check2 = false;
   
        } 
        else if (answ == 'r')
        {
            System.out.println("You Lose!");//check2 = false;
            System.exit(0);
        }
        
        
            }
        while (FinalProject.Cont() == 'y')
        {
             System.out.println("What will you do?");
            
             answ = scan.nextLine().charAt(0);
          if (answ == 'c')
       {
           System.out.println(" You chose to cry! While you cried a poison snake bit you!\n"
                   + " You DIED!!!! Score 0...Cry about that one why don't you");
                    System.exit(0);
          // a++;
          // check2 = false;
       }
       else if(answ == 'b')
       {
           System.out.println(" You chose to continue on your journey!");
           a++;check2 = false;
       }
       if (answ == 'd')
       {
           System.out.println(" You chose to drink the poison! You gained 2 times your health!\n"
                   + " Guess it wasn't poison after all!");
           System.out.println(PlayerHealthP()); a++;check2 = false;
       }
       else if(answ == 's')
       {
           System.out.println(" You chose save it! Use it wisely!"); a++;check2 = false;
       }
       if (answ == 'h')
       {
           System.out.println(" You tried picking up the sword but it's too heavy!\n"
                   + " You got trolled! Will you continue?"); a++;check2 = false;
       }
       if (answ == 't')
       {
           System.out.println(" The bunny bit you!"); a++;check2 = false;
       }
       else if(answ == 'w')
       {
           System.out.println(" You chose to walk away!"); a++;check2 = false;
       }
        if (answ == 'f')
        {
   System.out.println(BossFight() );check2 = false;a++;
   
        } 
        else if (answ == 'r')
        {
            System.out.println(" You Lose!");
            System.exit(0);//check2 = false;
        }
        if (a == 5)
        {
            System.out.println("You Found the cheese!!!!! You Win! Record score of 100 points "
                    + Continue.win());
            System.exit(0);
        }
        }
        
        
       }
    }
   
    public static String randomGame()  //generates random events
    {
        Random rand2 = new Random();
        int chance = rand2.nextInt(50);
      
       // Scanner scanN = new Scanner(System.in);
        String recall;
        String response = "";
        char answ;
        String Name;                //      Add more chance things to show up for better gameplay!
       //System.out.println(chance);
         if (chance >= 39){
                         response = "You found an enemy named " + names() +". He deals 1 damage a hit.\n His Hp is "
                                 + Enemy() + " What will you do? \n Fight (f)  "
                                 + "or Run (r)?"  ;
                                 
           
        }           
         else if(chance >= 29){
                        response = "You found a bunny" + "\n will you pet(t) it or leave it(w)?";
                        
                    }
         else if (chance >= 19){
                    response = "You found poison! Will you Drink it (d)\n"
                            + "Or will you save it (s)?";
                }
                else if(chance >= 9){
                response = "You found nothing! Choose to cry (c) or choose to continue (b)";
            }
                else if (chance >= 0){
            response = "You found a sword! It does 10 damage! Choose to take(h)?";
        }
                                                                  
        return response ;
        
    }
    
    public static int Enemy() //enemy hp
    {
        //int enemy;
        int enemyHP = 146;
        
        return enemyHP;
    }
    
    public static int HP() //random health
    {
        Random rand2 = new Random();
        //int rand3 = rand.nextInt(200);
        int HP = rand2.nextInt(200);
        int health = HP;
        return health;
    }
    
    public static int EnemyDamage() //damage
    {
        int punch = 10;
        int kick = 20;
        int hp = Enemy();
        //if (a == 'p')
            hp = hp - 10;
       // else 
            hp = hp - 20;
        return hp;
    }
    public static int PlayerHealth() //player health
    {
        int hp = 100;
        int damage = 1;
        hp = hp - damage;
        return hp;
    }
   public static int PlayerHealthP() //poison health
    {
        int hp = PlayerHealth();
        int damage = 1;
        hp = hp * 2;
        return hp;
    }
    public static char Cont() //continue game
    {
        Scanner scan = new Scanner(System.in);
        char cont;
        char end = 'e';
        
    System.out.println("Will you Continue?");   
    System.out.println("Yes (y) or No (n)");
    cont = scan.nextLine().charAt(0);
    if (cont == 'y' || cont == 'Y')
        System.out.println("Let's Go Then!" + randomGame());
    
    else if (cont == 'n'||cont=='N'){
        System.out.println("You Failed!!!!");
    System.exit(0);
    
    }
        
    return cont;
        
        
    } 
    public static String  BossFight() //simulated boss fight
    {
        int health = Enemy();
        int Hp = PlayerHealth();
        while (health > 0){
        Random rand1 = new Random();
        int chance = rand1.nextInt(11);
        System.out.println(health);
        String hit = "";
        
      if (chance <= 4){
    Hp--;
    hit = "You Missed! He hit you for 1 damage!" + Hp;
    System.out.println(hit);
    if (Hp == 0){
        health = 0;
        System.out.println("You lose!");
        hit = "You Lose!";
        return hit;
    }
}
else if (chance>=5){
    
    hit = "Nice Shot! You hit him for 5 damage!";
    health = health - 5;
    System.out.print(" Hp Enemy has remaining! " + health);
   // int pDamage = PlayerHealth() - 1;
    Hp--;
    System.out.println(hit +" "+ health + " Hp is remaining on the enemy!" + " \n"
            + " He hits you for 1 damage! "+ Hp); ;
}  
        
        //String Winner = "you Win!";
        //return Winner;
        
    }
        String Winner = "you Win!";
        return Winner;
        
}
    public static String  names() //random names 
    {
        Random rand = new Random();
       int name = rand.nextInt(4);
       String[] Names = {"John", "Steve", "Albert", "Jeff"};
       String n = Names[0];
       if (name == 0)
            n = Names[0];
       if(name == 1)
           n = Names[1];
       if(name == 2)
           n = Names[2];
       if (name == 3)
           n = Names[3];
      
       
       return n;
    } 
        
}    //return names[];
