/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;
import java.util.Scanner;
/**
 *
 * @author Guest1
 */
public class Continue 
{
      
         public static String a = "you win!";
         public static String win()
         {
             String b = a;//win class
             return b;
         }
} 

